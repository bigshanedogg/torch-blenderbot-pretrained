__author__ = 'lovit'
__name__ = 'KoBERTScore'
__version__ = '1.0.0'
