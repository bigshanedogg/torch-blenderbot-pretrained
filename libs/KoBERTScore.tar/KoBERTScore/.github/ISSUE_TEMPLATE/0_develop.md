---
name: Develop functions
about: Develop new function or class
labels: develop
---

```python
# usage example
```
