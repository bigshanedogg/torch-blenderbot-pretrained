---
name: Bug reporting
about: Bug reporting
labels: bug
---

```python
# Codes to reproduce error
```

```
Error message
```
