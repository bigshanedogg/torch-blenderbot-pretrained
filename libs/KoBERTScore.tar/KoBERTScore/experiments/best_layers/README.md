## Best-layer

| model | layer index | correlation (F)|
| --- | --- | --- |
| kcbert-base | 4 | 0.622 |
| koelectra | 12 | 0.334 |
| kobert | 2 | 0.190 |
| distilkobert | 12 | 0.098 |


